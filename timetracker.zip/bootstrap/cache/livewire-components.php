<?php return array (
  'common.sidenav' => 'App\\Http\\Livewire\\Common\\Sidenav',
  'profile' => 'App\\Http\\Livewire\\Profile',
);